#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> 
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include <pthread.h>
#include <zlib.h>

// function
int process_dirlist(int sockfd, char *option) {
    DIR *dir;
    struct dirent *entry;
    struct stat statbuf;
    char buffer[1024];
    int n;

    // Open the current directory
    dir = opendir(".");
    if (dir == NULL) {
        perror("opendir");
        return -1;
    }

    // Build the directory listing string
    bzero(buffer, 1024);
    while ((entry = readdir(dir)) != NULL) {
        // Get file information (optional for long listing)
        if (option[0] == '-' && option[1] == 'l') {
            if (stat(entry->d_name, &statbuf) == -1) {
                perror("stat");
                continue;
            }
            // Format information based on statbuf...
        }
        // Append filename to the buffer
        strcat(buffer, entry->d_name);
        strcat(buffer, "\n");
    }

    closedir(dir);

    // Send the directory listing to the client
    n = write(sockfd, buffer, strlen(buffer));
    if (n < 0) {
        perror("write error");
        return -1;
    }

    return 0;
}

int validate_dirlist(char *cmd) {
  // Check if the command starts with "dirlist" (case-insensitive)
  if (strncasecmp(cmd, "dirlist", 7) != 0) {
    return 0;
  }

  // Allow optional flags like "-l" or "-a" after a space
  cmd += 7;
  while (*cmd == ' ') {
    cmd++;
  }

  // Validate optional flags (modify as needed)
  if (*cmd != '\0') {
    if (*cmd == '-' && (cmd[1] == 'l' || cmd[1] == 'a') && cmd[2] == '\0') {
      return 1; // Valid command with flag "-l" (long listing) or "-a" (all files)
    } else {
      return 0; // Invalid flag
    }
  }

  // Valid command without any flags
  return 1;
}

int validate_w24fn(char *cmd) {
  """
  This function validates if the command is in the format "w24fn filename".

  Args:
      cmd: The command string to be validated.

  Returns:
      True if the command is valid, False otherwise.
  """
  if (!cmd) {
    return false;
  }

  // Split the command into words
  char *words[2];
  int num_words = sscanf(cmd, "%s %s", words[0], words[1]);

  // Check if there are exactly 2 words
  if (num_words != 2) {
    return false;
  }

  // Check if the first word is "w24fn" (case-insensitive)
  if (strcasecmp(words[0], "w24fn") != 0) {
    return false;
  }

  // Check if the second word is not empty
  return strlen(words[1]) > 0;
}

int validate_w24fz(char *cmd) {
  """
  This function validates if the command is in the format "w24fz <lower_size> <upper_size>"

  Args:
      cmd: The command string to validate.

  Returns:
      True if the command is valid, False otherwise.
  """
  // Check if the command starts with "w24fz" (case-sensitive)
  if (strncmp(cmd, "w24fz", 5) != 0) {
    return false;
  }

  // Skip past "w24fz" to start of arguments
  char *args = cmd + 5;

  // Check if there's a space after "w24fz"
  if (*args != ' ') {
    return false;
  }

  // Extract the lower size string
  char *lower_size_str = strtok(args, " ");
  if (lower_size_str == NULL) {
    return false;
  }

  // Extract the upper size string
  char *upper_size_str = strtok(NULL, " ");
  if (upper_size_str == NULL) {
    return false;

  // Check if there's anything else after the upper size
  if (strtok(NULL, " ") != NULL) {
    return false;
  }

  // Try converting the size strings to integers
  long int lower_size, upper_size;
  char *endptr;
  lower_size = strtol(lower_size_str, &endptr, 10);
  if (*endptr != '\0' || lower_size < 0) {
    return false;
  }
  upper_size = strtol(upper_size_str, &endptr, 10);
  if (*endptr != '\0' || upper_size < 0) {
    return false;
  }

  // Check if lower size is less than or equal to upper size
  if (lower_size > upper_size) {
    return false;
  }

  return true;
}

int validate_w24ft(char *cmd) {
  """
  This function validates the format of the w24ft command.

  Args:
      cmd: The client command string (e.g., "w24ft txt pdf doc").

  Returns:
      True if the command format is valid, False otherwise.
  """

  // Check if the command starts with "w24ft " (case-sensitive)
  if (!strncmp(cmd, "w24ft ", 6)) {
    cmd += 6;  // Move pointer to the start of the extension list
  } else {
    return false;
  }

  // Check if there are any spaces before extensions
  if (isspace(*cmd)) {
    return false;
  }

  // Validate each extension (optional)
  char *token;
  while ((token = strtok(cmd, " ")) != NULL) {
    // Check if the token is a valid file extension format (e.g., using regex)
    // You can implement your custom logic here for extension validation

    // Example using a simple check for length and alphanumeric characters
    if (strlen(token) < 1 || strlen(token) > 10 || !isalnum(*token)) {
      return false;
    }

    cmd = NULL;  // Reset strtok for next iteration
  }

  return true;
}

int validate_w24fdb(char *cmd) {
  """
  This function validates if the command is in the format "w24fdb YYYY-MM-DD".

  Args:
      cmd: The command string to validate.

  Returns:
      True if the command format is valid, False otherwise.
  """
  if (len(cmd) != 14 || strncmp(cmd, "w24fdb ", 7) != 0) {
    return false;
  }

  // Check if the date part is in YYYY-MM-DD format using regular expressions (POSIX)
  #include <regex.h>

  regex_t regex;
  int result;
  const char *date_pattern = "^[0-9]{4}-[0-1][0-9]-[0-3][0-9]$";

  // Compile the regular expression
  result = regcomp(&regex, date_pattern, REG_EXTENDED);
  if (result != 0) {
    perror("regcomp");
    return false;
  }

  // Perform matching
  result = regexec(&regex, cmd + 7, 0, NULL, 0);

  // Free compiled regular expression
  regfree(&regex);

  return result == 0; // 0 indicates successful match
}

int validate_w24fda(char *cmd) {
  """
  This function validates if the command is in the format "w24fda YYYY-MM-DD".

  Args:
      cmd: The command string to validate.

  Returns:
      True if the command format is valid, False otherwise.
  """
  if (strncmp(cmd, "w24fda ", strlen("w24fda ")) != 0) {
    return 0; // Not prefixed with "w24fda "
  }

  // Extract the date part
  char *date_str = cmd + strlen("w24fda ");

  // Check for valid date format (YYYY-MM-DD) using regular expression (optional)
  // You can uncomment and modify the following code if you want stricter validation
  // #include <regex.h>
  // regex_t regex;
  // int result = regcomp(&regex, "^[0-9]{4}-[0-1][0-9]-[0-3][0-9]$", REG_EXTENDED);
  // if (result != 0) {
  //   perror("regcomp");
  //   return 0;
  // }
  // result = regexec(&regex, date_str, 0, NULL, 0);
  // regfree(&regex);
  // if (result != 0) {
  //   return 0; // Invalid date format
  // }

  // Simpler validation (check length and delimiters)
  int len = strlen(date_str);
  return len == 10 && date_str[4] == '-' && date_str[7] == '-';
}

int compress_and_send_files(int sockfd, char *filepath, char *filename) {
    int fd, bytes_read, bytes_sent;
    char buffer[4096];  // Buffer for reading and sending file data
    z_stream c_stream;    // Zlib compression stream
    int ret;

    // Open the file
    fd = open(filepath, O_RDONLY);
    if (fd == -1) {
        perror("open");
        return -1;
    }

    // Initialize zlib compression stream
    c_stream.zalloc = Z_NULL;
    c_stream.zfree = Z_NULL;
    c_stream.opaque = Z_NULL;
    ret = deflateInit(&c_stream, Z_DEFAULT_COMPRESSION);
    if (ret != Z_OK) {
        close(fd);
        return -1;
    }

    // Send filename to client
    bytes_sent = write(sockfd, filename, strlen(filename));
    if (bytes_sent < 0) {
        perror("write filename");
        deflateEnd(&c_stream);
        close(fd);
        return -1;
    }

    // Read file data, compress, and send in chunks
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        c_stream.avail_in = bytes_read;
        c_stream.next_in = (Bytef *)buffer;

        do {
            c_stream.avail_out = sizeof(buffer);
            c_stream.next_out = (Bytef *)buffer;
            ret = deflate(&c_stream, Z_NO_FLUSH);  // Compress without flushing
            if (ret != Z_OK && ret != Z_STREAM_END) {
                perror("deflate");
                deflateEnd(&c_stream);
                close(fd);
                return -1;
            }

            // Send compressed data to client
            bytes_sent = write(sockfd, buffer, sizeof(buffer) - c_stream.avail_out);
            if (bytes_sent < 0) {
                perror("write compressed data");
                deflateEnd(&c_stream);
                close(fd);
                return -1;
            }
        } while (c_stream.avail_out == 0);
    }

    // Flush remaining compressed data
    do {
        c_stream.avail_in = 0;
        c_stream.next_in = NULL;
        ret = deflate(&c_stream, Z_FINISH);  // Flush remaining data
        if (ret != Z_STREAM_END) {
            perror("deflate flush");
            deflateEnd(&c_stream);
            close(fd);
            return -1;
        }

        bytes_sent = write(sockfd, buffer, sizeof(buffer) - c_stream.avail_out);
        if (bytes_sent < 0) {
            perror("write flushed data");
            deflateEnd(&c_stream);
            close(fd);
            return -1;
        }
    } while (c_stream.avail_out == 0);

    deflateEnd(&c_stream);
    close(fd);

    return 0;
}

// Server selection variables (modify these as needed)
#define SERVER1_IP "10.60.8.50"  // IP address of serverw24

// Thread structure
typedef struct {
    int client_socket;
} client_thread_args_t;

// Function to handle client requests
void *handle_client_request(void *args) {
    client_thread_args_t *client_args = (client_thread_args_t *)args;
    int client_socket = client_args->client_socket;
    char buffer[1024];
    int n;

    while (1) {
        // Read command from client
        bzero(buffer, 1024);
        n = read(client_socket, buffer, 1023);
        if (n <= 0) {
            break;
        }

        // Check for quit command
        if (strcmp(buffer, "quitc\n") == 0) {
            break;
        }

        // Validate and process the command
        if (validate_dirlist(buffer)) {
            process_dirlist(sockfd, buffer);
        } else if (validate_w24fn(char *cmd)) {
            process_w24fn(sockfd, buffer + 6);  // Extract filename after "w24fn "
        } else if (validate_w24fz(char *cmd)) {
            process_w24fz(sockfd, buffer + 6);  // Extract size range after "w24fz "
        } else if (validate_w24ft(char *cmd)) {
            process_w24ft(sockfd, buffer + 6);  // Extract extension list after "w24ft "
        } else if (validate_w24fdb(char *cmd)) {
            process_w24fdb(sockfd, buffer + 6);  // Extract date after "w24fdb "
        } else if (validate_w24fda(char *cmd)) {
            process_w24fda(sockfd, buffer + 6);  // Extract date after "w24fda "
        } else {
            // Send error message for invalid command
            n = write(sockfd, "Invalid command\n", 16);
            if (n < 0) {
                perror("write error");
            }
        }
    }

    close(client_socket);
    free(client_args);
    return NULL;
}

// Function to connect to the designated server
int connect_to_server(char *server_ip, int port_number) {
    int server_socket;
    struct sockaddr_in server_addr;

    // Create a socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    // Set up server address structure
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Connect to the server
    if (connect(server_socket, (struct sockaddr
 *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error connecting to server");
        return -1;
    }

    return server_socket;
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t clilen;
    pthread_t client_thread;

    // Create a socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    // Set up server address structure
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Choose a port number for mirror2 (e.g., 5678)
    int port_number = 5678;
    server_addr.sin_port = htons(port_number);

    // Bind the socket to the address
    if (bind(server_socket, (struct sockaddr *) &server_addr,
             sizeof(server_addr)) < 0) {
        perror("Error on binding");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    listen(server_socket, 5);
    clilen = sizeof(client_addr);

    printf("Server started on port %d\n", port_number);

    int connection_count = 0;  // Track the number of client connections

    while (1) {
        // Accept a new connection
        client_socket = accept(server_socket, (struct sockaddr *) &client_addr, &clilen);
        if (client_socket < 0) {
            perror("Error on accept");
            continue;
        }

        connection_count++;

        // Determine which server to connect to based on round-robin selection

        int target_server_socket;

        // Skip the first 3 connections handled by serverw24
        if (connection_count > 3) {
            // Handle connections for mirror2 in a round-robin fashion
            if (connection_count % 3 == 1) {
                target_server_socket = connect_to_server(SERVER1_IP, 9230);  // Connect to serverw24
            } else {
                target_server_socket = connect_to_server(server_addr.sin_addr.s_addr, port_number);  // Connect to itself (mirror2)
            }
        } else {
            // These connections (<= 3) should be handled by other servers (not mirror2)
            close(client_socket);
            continue;
        }

        // Check if connection to the target server was successful
        if (target_server_socket == -1) {
            perror("Error connecting to target server");
            close(client_socket);
            continue;
        }

        // Create a new thread to handle the client request using the connected server socket
        client_thread_args_t *client_args = malloc(sizeof(client_thread_args_t));
        client_args->client_socket = target_server_socket;

        if (pthread_create(&client_thread, NULL, handle_client_request, (void *)client_args) != 0) {
            perror("Error creating thread");
            close(target_server_socket);  // Close the connected server socket on error
            close(client_socket);
            free(client_args);
            continue;
        }
    }

    // Close the server socket (should not be reached in normal operation)
    close(server_socket);
    return 0;
}
