#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define MAX_BUFFER_SIZE 2048
#define BUFFER_SIZE 1024
#define SERVER_IP "10.60.8.51"  //No machine IP
//#define SERVER_IP "172.22.145.61"
#define SERVER_PORT 9230

// Function to receive the file from the server and store it in the w24project directory
void receiveFile(int clientSocket, const char *filename)
{
    // Open a new file for writing in the w24project directory
    char filepath[MAX_BUFFER_SIZE];
    snprintf(filepath, sizeof(filepath), "w24project/%s", filename);
    FILE *received_file = fopen(filepath, "wb");
    if (received_file == NULL)
    {
        perror("Error opening received file");
        return;
    }

    // Allocate memory for the buffer
    char *buffer = malloc(BUFFER_SIZE);
    if (buffer == NULL)
    {
        perror("Error allocating memory for buffer");
        fclose(received_file);
        return;
    }

    ssize_t received_bytes, written_bytes;

    // Receive the file data
    while ((received_bytes = read(clientSocket, buffer, BUFFER_SIZE)) > 0)
    {
        written_bytes = fwrite(buffer, 1, received_bytes, received_file);
        if (written_bytes < received_bytes)
        {
            perror("Error writing to file");
            free(buffer);
            fclose(received_file);
            return;
        }
    }

    // Free the allocated buffer
    free(buffer);

    // Close the received file
    fclose(received_file);

    printf("%s received and stored in w24project directory.\n", filename);
}

// Function to validate command syntax
int validateCommandSyntax(const char *command)
{
    // Tokenize the command to check the number of arguments
    char commandCopy[MAX_BUFFER_SIZE];
    strcpy(commandCopy, command);

    // Tokenize the command to check the number of arguments
    char *token = strtok(commandCopy, " ");
    int argCount = 0;
    while (token != NULL)
    {
        token = strtok(NULL, " ");
        argCount++;
    }

    // Check the command and its arguments based on the specified rules
    if (strncmp(command, "dirlist", 7) == 0 && (argCount == 2 || argCount == 3))
    {
        // Command 1: dirlist -a or dirlist -t
        return 1;
    }
    else if (strncmp(command, "w24fn", 6) == 0 && argCount == 2)
    {
        // Command 2: w24fn filename
        return 1;
    }
    else if (strncmp(command, "w24fz", 6) == 0 && argCount == 3)
    {
        // Command 3: w24fz size1 size2
        return 1;
    }
    else if (strncmp(command, "w24ft", 6) == 0 && argCount >= 3 && argCount <= 5)
    {
        // Command 4: w24ft <extension1> <extension2> <extension3>
        return 1;
    }
    else if ((strncmp(command, "w24fda", 7) == 0 || strncmp(command, "w24fdb", 7) == 0) && argCount == 2)
    {
        // Command 5: w24fda date or w24fdb date
        return 1;
    }
    else if (strncmp(command, "quitc", 5) == 0 && argCount == 1)
    {
        // Command 6: quitc
        return 1;
    }
    else
    {
        // Invalid syntax
        return 0;
    }
}

// Function to send and receive commands and data from the server
void sendReceiveCommand(int clientSocket, const char *command)
{
    // Send the command to the server
    if (send(clientSocket, command, strlen(command), 0) == -1)
    {
        perror("Error sending data to server");
        exit(EXIT_FAILURE);
    }

    // Receive and display the server's response
    char buffer[MAX_BUFFER_SIZE];
    memset(buffer, 0, sizeof(buffer));
    if (recv(clientSocket, buffer, sizeof(buffer), 0) == -1)
    {
        perror("Error receiving data from server");
        exit(EXIT_FAILURE);
    }

    printf("%s\n", buffer);

    // Check if the response indicates that the file was found and receive it if necessary
    if (strncmp(command, "w24fn", 6) == 0 || strncmp(command, "w24fz", 6) == 0 || strncmp(command, "w24ft", 6) == 0 || strncmp(command, "w24fdb", 7) == 0 || strncmp(command, "w24fda", 7) == 0)
    {
        if (strcmp(buffer, "File not found") != 0 && strcmp(buffer, "No file found") != 0)
        {
            receiveFile(clientSocket, "temp.tar.gz");
        }
    }
}

int main()
{
    int clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    if ((clientSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    // Set up server address struct
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Connect to server
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
    {
        perror("Error connecting to server");
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server.\n");

    // Main loop
    while (1)
    {
        // Get command input from the user
        printf("Enter a command (dirlist, w24fn, w24fz, w24ft, w24fda, w24fdb, quitc): ");
        if (fgets(buffer, sizeof(buffer), stdin) == NULL)
        {
            perror("Error reading command");
            break;
        }

        // Remove the newline character from the input
        buffer[strcspn(buffer, "\n")] = '\0';

        // Validate the syntax of the entered command
        if (validateCommandSyntax(buffer))
        {
            // Send the command to the server and receive the response
            sendReceiveCommand(clientSocket, buffer);

            // Check if the command is quitc
            if (strncmp(buffer, "quitc", 5) == 0)
            {
                // Close the socket
                close(clientSocket);
                printf("Connection closed.\n");
                break;
            }
        }
        else
        {
            // Print an error message for invalid command syntax
            printf("Invalid command syntax. Please enter a valid command.\n");
        }
    }

    return 0;
}
