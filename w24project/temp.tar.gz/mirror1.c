#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include <pthread.h>
#include <zlib.h>
#include <stdbool.h> 
#include <ctype.h>

// Function declarations
int process_dirlist(int sockfd, char *option);
int validate_dirlist(char *cmd);
int validate_w24fn(char *cmd);
int validate_w24fz(char *cmd);
int validate_w24ft(char *cmd);
int validate_w24fdb(char *cmd);
int validate_w24fda(char *cmd);
int compress_and_send_files(int sockfd, char *filepath, char *filename);
void *handle_client_request(void *args);
int connect_to_server(char *server_ip, int port_number);
void process_w24fn(int sockfd, char *filename);
void process_w24fz(int sockfd, char *size_range);
void process_w24ft(int sockfd, char *extensions);
void process_w24fdb(int sockfd, char *date);
void process_w24fda(int sockfd, char *date);

// Server selection variables (modify these as needed)
#define SERVER1_IP "10.60.8.50"  // IP address of serverw24

// Thread structure
typedef struct {
    int client_socket;
} client_thread_args_t;

void process_w24fn(int sockfd, char *filename) {
    // Open the file for reading
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    // Read and send the file contents in chunks
    char buffer[1024];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (write(sockfd, buffer, bytes_read) != bytes_read) {
            perror("Error writing to socket");
            fclose(file);
            return;
        }
    }

    // Close the file
    fclose(file);
}

void process_w24ft(int sockfd, char *extensions) {
    // Split the extensions string into individual extensions
    char *token = strtok(extensions, " ");
    while (token != NULL) {
        // Process each extension (example: print to stdout)
        printf("Extension: %s\n", token);
        
        // Move to the next extension
        token = strtok(NULL, " ");
    }
    
    // Send a confirmation message to the client
    char message[] = "Received and processed file extensions\n";
    write(sockfd, message, strlen(message));
}

void process_w24fz(int sockfd, char *size_range) {
    // Parse the size range
    char *lower_str = strtok(size_range, " ");
    char *upper_str = strtok(NULL, " ");

    // Convert the string representations to integers
    int lower_size = atoi(lower_str);
    int upper_size = atoi(upper_str);

    // Placeholder for processing logic
    printf("Processing files within size range %d to %d\n", lower_size, upper_size);

    // Example: Send acknowledgment to the client
    char response[256];
    sprintf(response, "Processed files within size range %d to %d\n", lower_size, upper_size);
    write(sockfd, response, strlen(response));
}



// Function to process directory listing
int process_dirlist(int sockfd, char *option) {
    DIR *dir;
    struct dirent *entry;
    struct stat statbuf;
    char buffer[1024];
    int n;

    // Open the current directory
    dir = opendir(".");
    if (dir == NULL) {
        perror("opendir");
        return -1;
    }

    // Build the directory listing string
    bzero(buffer, 1024);
    while ((entry = readdir(dir)) != NULL) {
        // Get file information (optional for long listing)
        if (option[0] == '-' && option[1] == 'l') {
            if (stat(entry->d_name, &statbuf) == -1) {
                perror("stat");
                continue;
            }
            // Format information based on statbuf...
        }
        // Append filename to the buffer
        strcat(buffer, entry->d_name);
        strcat(buffer, "\n");
    }

    closedir(dir);

    // Send the directory listing to the client
    n = write(sockfd, buffer, strlen(buffer));
    if (n < 0) {
        perror("write error");
        return -1;
    }

    return 0;
}

// Function to validate directory listing command
int validate_dirlist(char *cmd) {
    // Check if the command starts with "dirlist" (case-insensitive)
    if (strncasecmp(cmd, "dirlist", 7) != 0) {
        return 0;
    }

    // Allow optional flags like "-l" or "-a" after a space
    cmd += 7;
    while (*cmd == ' ') {
        cmd++;
    }

    // Validate optional flags (modify as needed)
    if (*cmd != '\0') {
        if (*cmd == '-' && (cmd[1] == 'l' || cmd[1] == 'a') && cmd[2] == '\0') {
            return 1; // Valid command with flag "-l" (long listing) or "-a" (all files)
        } else {
            return 0; // Invalid flag
        }
    }

    // Valid command without any flags
    return 1;
}

// Function to validate w24fn command
int validate_w24fn(char *cmd) {
    /* This function validates if the command is in the format "w24fn filename".

    Args:
        cmd: The command string to be validated.

    Returns:
        1 if the command is valid, 0 otherwise.*/
   
    if (!cmd) {
        return 0;
    }

    // Split the command into words
    char words[2][1024];
    int num_words = sscanf(cmd, "%s %s", words[0], words[1]);

    // Check if there are exactly 2 words
    if (num_words != 2) {
        return 0;
    }

    // Check if the first word is "w24fn" (case-insensitive)
    if (strcasecmp(words[0], "w24fn") != 0) {
        return 0;
    }

    // Check if the second word is not empty
    return strlen(words[1]) > 0;
}

// Function to validate w24fz command
int validate_w24fz(char *cmd) {
    /*This function validates if the command is in the format "w24fz <lower_size> <upper_size>"

    Args:
        cmd: The command string to validate.

    Returns:
        1 if the command is valid, 0 otherwise.*/
  
    // Check if the command starts with "w24fz" (case-sensitive)
    if (strncmp(cmd, "w24fz", 5) != 0) {
        return 0;
    }

    // Skip past "w24fz" to start of arguments
    char *args = cmd + 5;

    // Check if there's a space after "w24fz"
    if (*args != ' ') {
        return 0;
    }

    // Extract the lower size string
    char *lower_size_str = strtok(args, " ");
    if (lower_size_str == NULL) {
        return 0;
    }

    // Extract the upper size string
    char *upper_size_str = strtok(NULL, " ");
    if (upper_size_str == NULL) {
        return 0;
    }

    // Check if there's anything else after the upper size
    if (strtok(NULL, " ") != NULL) {
        return 0;
    }

    // Try converting the size strings to integers
    long int lower_size, upper_size;
    char *endptr;
    lower_size = strtol(lower_size_str, &endptr, 10);
    if (*endptr != '\0' || lower_size < 0) {
        return 0;
    }
    upper_size = strtol(upper_size_str, &endptr, 10);
    if (*endptr != '\0' || upper_size < 0) {
        return 0;
    }

    // Check if lower size is less than or equal to upper size
    if (lower_size > upper_size) {
        return 0;
    }

    return 1;
}

// Function to validate w24ft command
int validate_w24ft(char *cmd) {
    /*This function validates the format of the w24ft command.

    Args:
        cmd: The client command string (e.g., "w24ft txt pdf doc").

    Returns:
        1 if the command format is valid, 0 otherwise.*/
  
    // Check if the command starts with "w24ft " (case-sensitive)
    if (strncmp(cmd, "w24ft ", 6) != 0) {
        return 0;
    }

    cmd += 6;  // Move pointer to the start of the extension list

    // Check if there are any spaces before extensions
    if (isspace(*cmd)) {
        return 0;
    }

    // Validate each extension (optional)
    char *token;
    while ((token = strtok(cmd, " ")) != NULL) {
        // Check if the token is a valid file extension format (e.g., using regex)
        // You can implement your custom logic here for extension validation

        // Example using a simple check for length and alphanumeric characters
        if (strlen(token) < 1 || strlen(token) > 10 || !isalnum(*token)) {
            return 0;
        }

        cmd = NULL;  // Reset strtok for next iteration
    }

    return 1;
}

// Function to validate w24fdb command
int validate_w24fdb(char *cmd) {
    /*This function validates if the command is in the format "w24fdb YYYY-MM-DD".

    Args:
        cmd: The command string to validate.

    Returns:
        1 if the command format is valid, 0 otherwise.*/
  
    if (strlen(cmd) != 14 || strncmp(cmd, "w24fdb ", 7) != 0) {
        return 0;
    }

    // Check if the date part is in YYYY-MM-DD format using regular expressions (POSIX)
    // For simplicity, we're not using regex here

    return 1;
}

// Function to validate w24fda command
int validate_w24fda(char *cmd) {
    /*This function validates if the command is in the format "w24fda YYYY-MM-DD".

    Args:
        cmd: The command string to validate.

    Returns:
        1 if the command format is valid, 0 otherwise.*/
  
    if (strncmp(cmd, "w24fda ", strlen("w24fda ")) != 0) {
        return 0; // Not prefixed with "w24fda "
    }

    // Extract the date part
    char *date_str = cmd + strlen("w24fda ");

    // Check for valid date format (YYYY-MM-DD) using regular expression (optional)
    // You can uncomment and modify the following code if you want stricter validation
    // #include <regex.h>
    // regex_t regex;
    // int result = regcomp(&regex, "^[0-9]{4}-[0-1][0-9]-[0-3][0-9]$", REG_EXTENDED);
    // if (result != 0) {
    //   perror("regcomp");
    //   return 0;
    // }
    // result = regexec(&regex, date_str, 0, NULL, 0);
    // regfree(&regex);
    // if (result != 0) {
    //   return 0; // Invalid date format
    // }

    // Simpler validation (check length and delimiters)
    int len = strlen(date_str);
    return len == 10 && date_str[4] == '-' && date_str[7] == '-';
}

// Function to compress and send files
int compress_and_send_files(int sockfd, char *filepath, char *filename) {
    int fd, bytes_read, bytes_sent;
    char buffer[4096];  // Buffer for reading and sending file data
    z_stream c_stream;    // Zlib compression stream
    int ret;

    // Open the file
    fd = open(filepath, O_RDONLY);
    if (fd == -1) {
        perror("open");
        return -1;
    }

    // Initialize zlib compression stream
    c_stream.zalloc = Z_NULL;
    c_stream.zfree = Z_NULL;
    c_stream.opaque = Z_NULL;
    ret = deflateInit(&c_stream, Z_DEFAULT_COMPRESSION);
    if (ret != Z_OK) {
        close(fd);
        return -1;
    }

    // Send filename to client
    bytes_sent = write(sockfd, filename, strlen(filename));
    if (bytes_sent < 0) {
        perror("write filename");
        deflateEnd(&c_stream);
        close(fd);
        return -1;
    }

    // Read file data, compress, and send in chunks
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        c_stream.avail_in = bytes_read;
        c_stream.next_in = (Bytef *)buffer;

        do {
            c_stream.avail_out = sizeof(buffer);
            c_stream.next_out = (Bytef *)buffer;
            ret = deflate(&c_stream, Z_NO_FLUSH);  // Compress without flushing
            if (ret != Z_OK && ret != Z_STREAM_END) {
                perror("deflate");
                deflateEnd(&c_stream);
                close(fd);
                return -1;
            }

            // Send compressed data to client
            bytes_sent = write(sockfd, buffer, sizeof(buffer) - c_stream.avail_out);
            if (bytes_sent < 0) {
                perror("write compressed data");
                deflateEnd(&c_stream);
                close(fd);
                return -1;
            }
        } while (c_stream.avail_out == 0);
    }

    // Flush remaining compressed data
    do {
        c_stream.avail_in = 0;
        c_stream.next_in = NULL;
        ret = deflate(&c_stream, Z_FINISH);  // Flush remaining data
        if (ret != Z_STREAM_END) {
            perror("deflate flush");
            deflateEnd(&c_stream);
            close(fd);
            return -1;
        }

        bytes_sent = write(sockfd, buffer, sizeof(buffer) - c_stream.avail_out);
        if (bytes_sent < 0) {
            perror("write flushed data");
            deflateEnd(&c_stream);
            close(fd);
            return -1;
        }
    } while (c_stream.avail_out == 0);

    deflateEnd(&c_stream);
    close(fd);

    return 0;
}

// Function to handle client requests
void *handle_client_request(void *args) {
    client_thread_args_t *client_args = (client_thread_args_t *)args;
    int client_socket = client_args->client_socket;
    char buffer[1024];
    int n;

    while (1) {
        // Read command from client
        bzero(buffer, 1024);
        n = read(client_socket, buffer, 1023);
        if (n <= 0) {
            break;
        }

        // Check for quit command
        if (strcmp(buffer, "quitc\n") == 0) {
            break;
        }

        // Validate and process the command
        if (validate_dirlist(buffer)) {
            process_dirlist(client_socket, buffer);
        } else if (validate_w24fn(buffer)) {
            // Extract filename after "w24fn "
            process_w24fn(client_socket, buffer + 6);
        } else if (validate_w24fz(buffer)) {
            // Extract size range after "w24fz "
            process_w24fz(client_socket, buffer + 6);
        } else if (validate_w24ft(buffer)) {
            // Extract extension list after "w24ft "
            process_w24ft(client_socket, buffer + 6);
        } else if (validate_w24fdb(buffer)) {
            // Extract date after "w24fdb "
            process_w24fdb(client_socket, buffer + 7);
        } else if (validate_w24fda(buffer)) {
            // Extract date after "w24fda "
            process_w24fda(client_socket, buffer + 7);
        } else {
            // Invalid command
            write(client_socket, "Invalid command\n", 16);
        }
    }

    // Close client socket and free thread args
    close(client_socket);
    free(client_args);
    pthread_exit(NULL);
}

// Function to connect to the server
int connect_to_server(char *server_ip, int port_number) {
    int sockfd;
    struct sockaddr_in server_addr;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return -1;
    }

    // Initialize server address struct
    bzero((char *)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(server_ip);
    server_addr.sin_port = htons(port_number);

    // Connect to server
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect");
        close(sockfd);
        return -1;
    }

    return sockfd;
}

int main() {
    int sockfd, client_socket, port_number;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    pthread_t tid;
    client_thread_args_t *client_args;

    // Set server port number
    port_number = 6000;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Initialize server address struct
    bzero((char *)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port_number);

    // Bind socket to server address
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Listen for client connections
    if (listen(sockfd, 5) < 0) {
        perror("listen");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Server running on port %d...\n", port_number);

    // Accept client connections and handle requests in separate threads
    while (1) {
        // Accept client connection
        client_socket = accept(sockfd, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("accept");
            continue;
        }

        // Allocate memory for client thread arguments
        client_args = (client_thread_args_t *)malloc(sizeof(client_thread_args_t));
        if (client_args == NULL) {
            perror("malloc");
            close(client_socket);
            continue;
        }

        // Initialize client thread arguments
        client_args->client_socket = client_socket;

        // Create thread to handle client request
        if (pthread_create(&tid, NULL, handle_client_request, (void *)client_args) != 0) {
            perror("pthread_create");
            free(client_args);
            close(client_socket);
            continue;
        }

        // Detach thread (auto cleanup)
        pthread_detach(tid);
    }

    close(sockfd);
    return 0;
}
