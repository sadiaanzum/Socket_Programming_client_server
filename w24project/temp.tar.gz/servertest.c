#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 9230
#define BUFFER_SIZE 1024

// Function prototypes
void performDirectoryListingAlphabetically(int client_socket);
void performDirectoryListingByCreationTime(int client_socket);
void handleFileNameQuery(int client_socket, const char* filename);
void handleFileSizeRangeQuery(int client_socket, int size1, int size2);
void handleFileTypeQuery(int client_socket, const char* extension_list);
void handleFilesCreatedBeforeDateQuery(int client_socket, const char* date);
void handleFilesCreatedAfterDateQuery(int client_socket, const char* date);

void performDirectoryListingAlphabetically(int client_socket) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[] = "ls -d -1 */";

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send the directory name to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void handleFileNameQuery(int client_socket, const char* filename) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[BUFFER_SIZE];

    // Create the command to search for the file
    snprintf(command, sizeof(command), "find ~ -name '%s' -printf '%%f\\t%%s\\t%%TD %%TT\\t%%m\\n'", filename);

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    if (fgets(result, sizeof(result), fp) != NULL) {
        // Send file information to the client
        send(client_socket, result, strlen(result), 0);
    } else {
        // File not found
        send(client_socket, "File not found", strlen("File not found"), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void handleFileSizeRangeQuery(int client_socket, int size1, int size2) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[BUFFER_SIZE];

    // Create the command to find files within the specified size range
    snprintf(command, sizeof(command), "find ~ -type f -size +%dB -size -%dB", size1, size2);

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send file information to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void handleFileTypeQuery(int client_socket, const char* extension_list) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[BUFFER_SIZE];

    // Create the command to find files with specified extensions
    snprintf(command, sizeof(command), "find ~ -type f -name '*.%s'", extension_list);

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send file information to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void handleFilesCreatedBeforeDateQuery(int client_socket, const char* date) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[BUFFER_SIZE];

    // Create the command to find files created before the specified date
    snprintf(command, sizeof(command), "find ~ -type f -newermt '%s' -printf '%%f\\t%%s\\t%%TD %%TT\\t%%m\\n'", date);

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send file information to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void handleFilesCreatedAfterDateQuery(int client_socket, const char* date) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[BUFFER_SIZE];

    // Create the command to find files created after the specified date
    snprintf(command, sizeof(command), "find ~ -type f ! -newermt '%s' -printf '%%f\\t%%s\\t%%TD %%TT\\t%%m\\n'", date);

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send file information to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void performDirectoryListingByCreationTime(int client_socket) {
    FILE *fp;
    char result[BUFFER_SIZE] = "";
    char command[] = "ls -lt --time=ctime --group-directories-first";

    // Execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("Error executing command");
        exit(EXIT_FAILURE);
    }

    // Read the output of the command
    while (fgets(result, sizeof(result), fp) != NULL) {
        // Send the directory listing to the client
        send(client_socket, result, strlen(result), 0);
    }

    // Close the file pointer
    pclose(fp);
}

void crequest(int client_socket) {
    char buffer[BUFFER_SIZE];
    int bytes_received;

    while (1) {
        // Receive command from client
        bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received < 0) {
            perror("Error in receiving data from client");
            break;
        } else if (bytes_received == 0) {
            printf("Client disconnected\n");
            break;
        }

        buffer[bytes_received] = '\0';

        // Process command
        if (strncmp(buffer, "dirlist -a", 10) == 0) {
            // Perform directory listing alphabetically
            performDirectoryListingAlphabetically(client_socket);
        } else if (strncmp(buffer, "dirlist -t", 10) == 0) {
            // Perform directory listing by creation time
            performDirectoryListingByCreationTime(client_socket);
        } else if (strncmp(buffer, "w24fn", 5) == 0) {
            // Handle file name query
            // Extract filename from buffer
            char *filename = buffer + 6; // Assuming the command format is "w24fn filename"
            handleFileNameQuery(client_socket, filename);
        } else if (strncmp(buffer, "w24fz", 5) == 0) {
            // Handle file size range query
            // Extract size1 and size2 from buffer
            int size1, size2;
            scanf(buffer + 6, "%d %d", &size1, &size2); // Assuming the command format is "w24fz size1 size2"
            handleFileSizeRangeQuery(client_socket, size1, size2);
        } else if (strncmp(buffer, "w24ft", 5) == 0) {
            // Handle file type query
            // Extract extension list from buffer
            char *extension_list = buffer + 6; // Assuming the command format is "w24ft extension_list"
            handleFileTypeQuery(client_socket, extension_list);
        } else if (strncmp(buffer, "w24fdb", 6) == 0) {
            // Handle files created before date query
            // Extract date from buffer
            char *date = buffer + 7; // Assuming the command format is "w24fdb date"
            handleFilesCreatedBeforeDateQuery(client_socket, date);
        } else if (strncmp(buffer, "w24fda", 6) == 0) {
            // Handle files created after date query
            // Extract date from buffer
            char *date = buffer + 7; // Assuming the command format is "w24fda date"
            handleFilesCreatedAfterDateQuery(client_socket, date);
        } else if (strncmp(buffer, "quitc", 5) == 0) {
            // Close client connection
            printf("Closing client connection\n");
            break;
        } else {
            send(client_socket, "Invalid command", strlen("Invalid command"), 0);
        }
    }

    // Close client socket
    close(client_socket);
}


int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len;

    // Create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Error in creating server socket");
        exit(EXIT_FAILURE);
    }

    // Initialize server address struct
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind server socket to address and port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Error in binding server socket");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Error in listening");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d\n", PORT);

    while (1) {
        // Accept incoming connection
        client_addr_len = sizeof(client_addr);
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Error in accepting connection");
            continue;
        }

        printf("Accepted connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Fork a child process to handle client request
        pid_t pid = fork();
        if (pid == 0) {  // Child process
            close(server_socket);  // Close server socket in child process
            crequest(client_socket);  // Handle client request
            exit(EXIT_SUCCESS);
        } else if (pid < 0) {
            perror("Error in forking");
        } else {  // Parent process
            close(client_socket);  // Close client socket in parent process
        }
    }

    // Close server socket
    close(server_socket);

    return 0;
}
