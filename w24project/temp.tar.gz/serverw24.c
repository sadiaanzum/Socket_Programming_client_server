#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>

#define PORT 9230 // Port to listen on

// Function prototypes
void crequest(int args);
int process_dirlist(int sockfd, char *option);
int validate_dirlist(char *cmd);
int validate_w24fn(char *cmd);
int validate_w24fz(char *cmd);
int validate_w24ft(char *cmd);
int validate_w24fdb(char *cmd);
int validate_w24fda(char *cmd);
int process_w24fn(int sockfd, char *filename);
int process_w24fz(int sockfd, char *cmd);
int process_w24ft(int sockfd, char *cmd);
int process_w24fdb(int sockfd, char *cmd);
int process_w24fda(int sockfd, char *cmd);
int compress_and_send_files(int sockfd, char *filepath, char *archive_path, int min_size, int max_size);  // Assuming this version takes filepath, filename, min_size, and max_size
int compare_timestamps(const void *a, const void *b);  // Function to compare timestamps

int sockfd;
int n;

struct file_info {
    char name[256];
    time_t timestamp;
};

typedef struct {
    int client_socket;
} client_thread_args_t;


// Function to validate dirlist command syntax
int validate_dirlist(char *cmd) {
    return (strcmp(cmd, "dirlist -a\n") == 0 || strcmp(cmd, "dirlist -t\n") == 0);
}

// Function to validate w24fn command syntax
int validate_w24fn(char *cmd) {
    return (strncmp(cmd, "w24fn ", 6) == 0 && strlen(cmd) > 6);
}

// Function to validate w24fz command syntax
int validate_w24fz(char *cmd) {
    int size1, size2;
    return (sscanf(cmd, "w24fz %d %d", &size1, &size2) == 2 && size1 <= size2);
}

// Function to validate w24ft command syntax
int validate_w24ft(char *cmd) {
    int space_count = 0;
    for (int i = 0; cmd[i] != '\0'; i++) {
        if (cmd[i] == ' ') {
            space_count++;
        }
    }
    return (space_count >= 1 && space_count <= 3);
}

// Function to validate w24fdb command syntax
int validate_w24fdb(char *cmd) {
    return (strncmp(cmd, "w24fdb ", 7) == 0 && strlen(cmd) > 7);
}

// Function to validate w24fda command syntax
int validate_w24fda(char *cmd) {
    return (strncmp(cmd, "w24fda ", 7) == 0 && strlen(cmd) > 7);
}

// Function to process dirlist command
int process_dirlist(int sockfd, char *option) {
    DIR *dir;
    struct dirent *ent;
    char message[1024];
    int n;

    dir = opendir(".");
    if (dir == NULL) {
        perror("opendir error");
        return -1;
    }

    if (strcmp(option, "-a\n") == 0) {
        // List subdirectories in alphabetical order
        while ((ent = readdir(dir)) != NULL) {
            if (ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0) {
                strcat(message, ent->d_name);
                strcat(message, "\n");
            }
        }
    } else {
        // List subdirectories in creation time order (approximate)
        struct file_info {
            char name[256];
            time_t timestamp;
        };
        struct file_info *files;
        int num_files = 0, allocated_files = 0;

        rewinddir(dir);
        while ((ent = readdir(dir)) != NULL) {
            if (ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0) {
                if (num_files == allocated_files) {
                    allocated_files += 10;
                    files = realloc(files, allocated_files *
                    sizeof(struct file_info));
                }
                struct stat statbuf;
                if (stat(ent->d_name, &statbuf) == 0) {
                    files[num_files].timestamp = statbuf.st_mtime;
                    strcpy(files[num_files].name, ent->d_name);
                    num_files++;
                }
            }
        }
        closedir(dir);

        // Sort files by timestamp
        qsort(files, num_files, sizeof(struct file_info), compare_timestamps);

        // Build message with sorted directory list
        for (int i = 0; i < num_files; i++) {
            strcat(message, files[i].name);
            strcat(message, "\n");
        }
        free(files);
    }

    closedir(dir);
    strcat(message, "\n");
    n = write(sockfd, message, strlen(message));
    if (n < 0) {
        perror("write error");
        return -1;
    }

    return 0;
}

// Function to compare timestamps (qsort helper)
int compare_timestamps(const void *a, const void *b) {
    struct file_info *fa = (struct file_info *)a;
    struct file_info *fb = (struct file_info *)b;
    return fa->timestamp - fb->timestamp;
}

// Function to process w24fn command
int process_w24fn(int sockfd, char *filename) {
    char filepath[1024];
    struct stat statbuf;
    char message[1024];
    int n;

    sprintf(filepath, "./%s", filename);
    if (stat(filepath, &statbuf) == 0) {
        snprintf(message, sizeof(message), "%s %ld %s %s\n", filename, statbuf.st_size,
                 ctime(&statbuf.st_mtime), (S_ISDIR(statbuf.st_mode) ? "d" : "-"));
        n = write(sockfd, message, strlen(message));
        if (n < 0) {
            perror("write error");
            return -1;
        }
    } else {
        n = write(sockfd, "File not found\n", 15);
        if (n < 0) {
            perror("write error");
            return -1;
        }
    }

    return 0;
}

// Function to process w24fz command
int process_w24fz(int sockfd, char *cmd) {
    int size1, size2;
    sscanf(cmd, "%d %d", &size1, &size2);

    if (size1 > size2) {
        n = write(sockfd, "Invalid size range\n", 19);
        if (n < 0) {
            perror("write error");
            return -1;
        }
        return -1;
    }

    char archive_path[1024];
    sprintf(archive_path, "w24project/temp.tar.gz");
    if (compress_and_send_files(sockfd, ".", archive_path, size1, size2) == -1) {
        return -1;
    }

    return 0;
}

// Function to process w24ft command
int process_w24ft(int sockfd, char *cmd) {
    char extensions[100][10];
    int num_extensions = 0;
    char *token = strtok(cmd, " ");
    while (token != NULL) {
        if (strlen(token) > 3) {
            n = write(sockfd, "Invalid extension\n", 19);
            if (n < 0) {
                perror("write error");
                return -1;
            }
            return -1;
        }
        strcpy(extensions[num_extensions++], token);
        token = strtok(NULL, " ");
    }

    char archive_path[1024];
    sprintf(archive_path, "w24project/temp.tar.gz");
    if (compress_and_send_files(sockfd, ".", archive_path, -1, -1) == -1) {
        return -1;
    }

    return 0;
}

// Function to process w24fdb command
int process_w24fdb(int sockfd, char *date_str) {
    struct tm tm;
    time_t timestamp;
    char archive_path[1024];

    if (strptime(date_str, "%Y-%m-%d", &tm) == NULL) {
        n = write(sockfd, "Invalid date format\n", 21);
        if (n < 0) {
            perror("write error");
            return -1;
        }
        return -1;
    }

    timestamp = mktime(&tm);
    sprintf(archive_path, "w24project/temp.tar.gz");
    if (compress_and_send_files(sockfd, ".", archive_path, -1, timestamp) == -1) {
        return -1;
    }

    return 0;
}

// Function to process w24fda command
int process_w24fda(int sockfd, char *date_str) {
    struct tm tm;
    time_t timestamp;
    char archive_path[1024];

    if (strptime(date_str, "%Y-%m-%d", &tm) == NULL) {
        n = write(sockfd, "Invalid date format\n", 21);
        if (n < 0) {
            perror("write error");
            return -1;
        }
        return -1;
    }

    timestamp = mktime(&tm);
    sprintf(archive_path, "w24project/temp.tar.gz");
    if (compress_and_send_files(sockfd, ".", archive_path, timestamp, -1) == -1) {
        return -1;
    }

    return 0;
}

// Function to compress and send files
int compress_and_send_files(int sockfd, char *filepath, char *archive_path, int min_size, int max_size) {
    char command[1024];
    FILE *fp;
    int status;

    // Create w24project directory if it doesn't exist
    if (access("w24project", F_OK) == -1 && mkdir("w24project", 0755) == -1) {
        perror("mkdir error");
        return -1;
    }

    // Create archive using system call (replace with system-independent library if needed)
    sprintf(command, "tar -czvf %s %s", archive_path, filepath);
    fp = popen(command, "w");
    if (fp == NULL) {
        perror("popen error");
        return -1;
    }
    status = pclose(fp);
    if (status != 0) {
        perror("tar error");
        return -1;
    }

    // Send archive to client
    fp = fopen(archive_path, "rb");
    if (fp == NULL) {
        perror("fopen error");
        return -1;
    }
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    rewind(fp);

    n = write(sockfd, &file_size, sizeof(long));
    if (n < 0) {
        perror("write error");
        fclose(fp);
        return -1;
    }

    char buffer[1024];
    while ((n = fread(buffer, 1, sizeof(buffer), fp)) > 0) {
        if (write(sockfd, buffer, n) < 0) {
            perror("write error");
            fclose(fp);
            return -1;
        }
    }

    fclose(fp);
    return 0;
}

int main() {
    int server_socket, new_sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t clilen;

    // Create a socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket creation failed");
        exit(1);
    }

    // Set server address details
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket to the address
    if (bind(sockfd, (struct sockaddr *) &server_addr,
             sizeof(server_addr)) < 0) {
        perror("bind failed");
        exit(1);
    }

    // Listen for incoming connections
    listen(sockfd, 5);
    clilen = sizeof(client_addr);

    while (1) {
        // Accept incoming connection
        clilen = sizeof(client_addr);
        new_sockfd = accept(sockfd, (struct sockaddr *)&client_addr, &clilen);
        if (new_sockfd < 0) {
            perror("accepting connection failed");
            continue;
        }

        printf("Accepted connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Fork a child process to handle client request
        pid_t pid = fork();
        if (pid == 0) {  // Child process
            close(server_socket);  // Close server socket in child process
            crequest(new_sockfd);  // Handle client request
            exit(EXIT_SUCCESS);
        } else if (pid < 0) {
            perror("Error in forking");
        } else {  // Parent process
            close(new_sockfd);  // Close client socket in parent process
        }
    }

    // Close server socket
    close(server_socket);

    return 0;
}

// Function to handle client requests
void crequest(int args) {
    client_thread_args_t *client_args = (client_thread_args_t *)args;
    int client_socket = client_args->client_socket;
    char buffer[1024];
    int n;

    while (1) {
        // Read command from client
        bzero(buffer, 1024);
        n = read(sockfd, buffer, 1023);
        if (n <= 0) {
            break;
        }

        // Check for quit command
        if (strcmp(buffer, "quitc\n") == 0) {
            break;
        }

        // Validate and process the command
        if (validate_dirlist(buffer)) {
            process_dirlist(sockfd, buffer);
        } else if (validate_w24fn(buffer)) {
            process_w24fn(sockfd, buffer + 6);  // Extract filename after "w24fn "
        } else if (validate_w24fz(buffer)) {
            process_w24fz(sockfd, buffer + 6);  // Extract size range after "w24fz "
        } else if (validate_w24ft(buffer)) {
            process_w24ft(sockfd, buffer + 6);  // Extract extension list after "w24ft "
        } else if (validate_w24fdb(buffer)) {
            process_w24fdb(sockfd, buffer + 6);  // Extract date after "w24fdb "
        } else if (validate_w24fda(buffer)) {
            process_w24fda(sockfd, buffer + 6);  // Extract date after "w24fda "
        } else {
            // Send error message for invalid command
            n = write(sockfd, "Invalid command\n", 16);
            if (n < 0) {
                perror("write error");
            }
        }
    }
    close(client_socket);
    free(client_args);
    return;
}